﻿using System.ComponentModel.DataAnnotations;

namespace COMP2139_Labs.Models
{
    public class Project
    {

        public int ProjectId { get; set; }

        [Required] // making sure it is not empty
        public required string Name { get; set; }

        public string? Description { get; set; }

        [DataType(DataType.Date)] // Making sure date time format is validated
        public DateTime StartDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }

        public string? Status { get; set; }

    }
}

